<?php

	//koneksi
    include "../../../partials/functions.php";
	
	//variabel
	$NIS = $_POST['nis'];
	$Password = $_POST['password'];
	$ID = $_POST['number'];
	$jk = $_POST['jk'];
	$alamat = $_POST['alamat'];
	
	//query
	$tambah = mysql_query("insert into siswa values('$NIS', '$Password', '$ID', '$jk', '$alamat')");
	
	//pesan
	if($tambah){
		echo"<script> alert('Data Berhasil Ditambah');
		location.href = 'http://localhost/design-adm/index.php#siswa';
		</script>";
	}else{
		echo"<script> alert('Penambahan Data Gagal');
		location.href = '../../../pages/form/tambah/siswa.php';
		</script>";
	}
?>