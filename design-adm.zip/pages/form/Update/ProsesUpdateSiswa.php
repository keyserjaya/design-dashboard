<?php
	include "../../../partials/functions.php";
	
	//variabel data
	$nisSebelumnya = $_GET['nisSebelum'];
	$nis = $_POST['nis'];
	$password = $_POST['password'];
	$number = $_POST['number'];
	$JK = $_POST['jk'];
	$alamat = $_POST['alamat'];
	
	//query
	$update = mysql_query("update siswa set NIS=$nis, nama='$password', id_jurusan='$number', jk='$JK', alamat='$alamat' where NIS=$nisSebelumnya");
	
	//pesan
	if ($update){
		echo "<script>alert('Data Berhasil di ubah');
		location.href ='http://localhost/design-adm/index.php#siswa';
		</script>";
	}else
		echo "<script>alert('Data Gagal di ubah');
		location.href ='http://localhost/design-adm/index.php#siswa';
		</script>";
?>