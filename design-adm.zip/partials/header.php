<header>
	<div id="title-page">
		<a href="<?php siteUrl("index.php");  ?>">
			<i class="icon ion-android-refresh"></i>
		</a>
		<h2>DASHBOARD ADMIN</h2>
	</div>
	<a href="#" id="keluar"><i class="icon ion-log-out"></i> Keluar</a>
</header>