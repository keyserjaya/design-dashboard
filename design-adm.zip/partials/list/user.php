<div id="dashboard">			
	<div id="user-team">
		<div class="card">
			<div class="header">
				<h3>TEAM ASSASINS</h3>
				<hr>
			</div>
			<div class="list">
				<ul>
					<li>
						<a href="">
							<span class="avatar"></span>
							<div class="desc">
								<h6 class="name">Bagus Mantonafi</h6>
								<p>Full-Stack Developer</p>
							</div>
						</a>
					</li>
					<li>
						<a href="">
							<span class="avatar"></span>
							<div class="desc">
								<h6 class="name">Sholahudin</h6>
								<p>Front-end Developer</p>
							</div>
						</a>
					</li>
					<li>
						<a href="">
							<span class="avatar"></span>
							<div class="desc">
								<h6 class="name">Jaya Temara</h6>
								<p>Game Developer</p>
							</div>
						</a>
					</li>
					<li>
						<a href="">
							<span class="avatar"></span>
							<div class="desc">
								<h6 class="name">Hendry Roganda L</h6>
								<p>Master Gamer</p>
							</div>
						</a>
					</li>
					<li>
						<a href="">
							<span class="avatar"></span>
							<div class="desc">
								<h6 class="name">Bagus Krisna</h6>
								<p>DJ</p>
							</div>
						</a>
					</li>
					<li>
						<a href="">
							<span class="avatar"></span>
							<div class="desc">
								<h6 class="name">Aditya Pratama</h6>
								<p>Futsal Lovers</p>
							</div>
						</a>
					</li>
				</ul>
			</div>
			<div class="footer">
				<a href="pages/form/tambah/user.php" class="btn-tambah">TAMBAH USER</a>
			</div>
		</div>
	</div><!-- user team -->
</div><!-- id dashboard and user admin -->
