<div id="guru">
	<div class="list-table">
		<div class="card">
			<div class="header">
				<h3>DAFTAR PENGAJAR</h3>
				<hr>
			</div>
			<div class="command">
				
				<a href="pages/form/tambah/guru.php" class="btn-tambah">TAMBAH PENGAJAR</a>
			</div>
			<div class="list">
			<div class="scrolling">
				<table>
					<thead>
						<tr>
							<th><i class="icon ion-pound"></i></th>
							<th>ID Guru</th>
							<th>Nama Guru</th>
							<th>Jenis Kelamin</th>
							<th>Alamat</th>
							<th colspan="2" align="center">Action</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>1</td>
							<td>P01</td>
							<td>Sukijan</td>
							<td>Laki - Laki</td>
							<td>Denpasar, ID</td>
							<td>
								<a href="" class="hapus">
									HAPUS
								<i class="icon ion-ios-trash-outline"></i>
								</a>
							</td>

							<td>
								<a href="" class="edit">
									EDIT
								<i class="icon ion-edit"></i>
								</a>
							</td>
						</tr>
						<tr>
							<td>2</td>
							<td>PO2</td>
							<td>Sudirman</td>
							<td>Laki - Laki</td>
							<td>Denpasar, ID</td>
							<td>
								<a href="" class="hapus">
									HAPUS
								<i class="icon ion-ios-trash-outline"></i>
								</a>
							</td>

							<td>
								<a href="" class="edit">
									EDIT
								<i class="icon ion-edit"></i>
								</a>
							</td>
						</tr>
						<tr>
							<td>3</td>
							<td>P03</td>
							<td>Suparman</td>
							<td>Laki - Laki</td>
							<td>Denpasar, ID</td>
							<td>
								<a href="" class="hapus">
									HAPUS
								<i class="icon ion-ios-trash-outline"></i>
								</a>
							</td>

							<td>
								<a href="" class="edit">
									EDIT
								<i class="icon ion-edit"></i>
								</a>
							</td>
						</tr>
						<tr>
							<td>4</td>
							<td>P04</td>
							<td>Astuti</td>
							<td>Laki - Laki</td>
							<td>Denpasar, ID</td>
							<td>
								<a href="" class="hapus">
									HAPUS
								<i class="icon ion-ios-trash-outline"></i>
								</a>
							</td>

							<td>
								<a href="" class="edit">
									EDIT
								<i class="icon ion-edit"></i>
								</a>
							</td>
						</tr>

						<tr>
							<td>4</td>
							<td>P04</td>
							<td>Astuti</td>
							<td>Laki - Laki</td>
							<td>Denpasar, ID</td>
							<td>
								<a href="" class="hapus">
									HAPUS
								<i class="icon ion-ios-trash-outline"></i>
								</a>
							</td>

							<td>
								<a href="" class="edit">
									EDIT
								<i class="icon ion-edit"></i>
								</a>
							</td>
						</tr>

						<tr>
							<td>4</td>
							<td>P04</td>
							<td>Astuti</td>
							<td>Laki - Laki</td>
							<td>Denpasar, ID</td>
							<td>
								<a href="" class="hapus">
									HAPUS
								<i class="icon ion-ios-trash-outline"></i>
								</a>
							</td>

							<td>
								<a href="" class="edit">
									EDIT
								<i class="icon ion-edit"></i>
								</a>
							</td>
						</tr>

						<tr>
							<td>4</td>
							<td>P04</td>
							<td>Astuti</td>
							<td>Laki - Laki</td>
							<td>Denpasar, ID</td>
							<td>
								<a href="" class="hapus">
									HAPUS
								<i class="icon ion-ios-trash-outline"></i>
								</a>
							</td>

							<td>
								<a href="" class="edit">
									EDIT
								<i class="icon ion-edit"></i>
								</a>
							</td>
						</tr>

						<tr>
							<td>4</td>
							<td>P04</td>
							<td>Astuti</td>
							<td>Laki - Laki</td>
							<td>Denpasar, ID</td>
							<td>
								<a href="" class="hapus">
									HAPUS
								<i class="icon ion-ios-trash-outline"></i>
								</a>
							</td>

							<td>
								<a href="" class="edit">
									EDIT
								<i class="icon ion-edit"></i>
								</a>
							</td>
						</tr>

						<tr>
							<td>4</td>
							<td>P04</td>
							<td>Astuti</td>
							<td>Laki - Laki</td>
							<td>Denpasar, ID</td>
							<td>
								<a href="" class="hapus">
									HAPUS
								<i class="icon ion-ios-trash-outline"></i>
								</a>
							</td>

							<td>
								<a href="" class="edit">
									EDIT
								<i class="icon ion-edit"></i>
								</a>
							</td>
						</tr>

						<tr>
							<td>4</td>
							<td>P04</td>
							<td>Astuti</td>
							<td>Laki - Laki</td>
							<td>Denpasar, ID</td>
							<td>
								<a href="" class="hapus">
									HAPUS
								<i class="icon ion-ios-trash-outline"></i>
								</a>
							</td>

							<td>
								<a href="" class="edit">
									EDIT
								<i class="icon ion-edit"></i>
								</a>
							</td>
						</tr>
					</tbody>
				</table>
				</div>
			</div><!-- list -->
		</div><!-- card -->
	</div><!-- list table -->
</div><!-- guru -->