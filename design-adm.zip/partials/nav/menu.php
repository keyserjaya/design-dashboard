<div id="user">
<!-- 	<div class="avatar">
		<img src="image/user/bagus.jpg">
	</div> -->

	<div class="avatar">
		<span></span>
	</div>
	<div class="profil">
		<h1>Bagus Mantonafi</h1>
		<h2>ADMIN</h2>
	</div>
</div>
<div id="menu">
	<ul>
		<li class="active">
			<a href="http://localhost/design-adm/index.php#dashboard">
				<i class="icon ion-ios-analytics-outline"></i>
				DASHBOARD
			</a>
		</li>
		<li>
			<a href="http://localhost/design-adm/index.php#dashboard">
				<i class="icon ion-ios-people"></i>
				USER ADMIN
			</a>
			<span class="badge">6</span>
		</li>
		<li>
			<a href="http://localhost/design-adm/index.php#siswa">
				<i class="icon ion-university"></i>
				SISWA TERDAFTAR
			</a>
			<span class="badge">428</span>
		</li>
		<li>
			<a href="http://localhost/design-adm/index.php#guru">
				<i class="icon ion-person-stalker"></i>
				GURU PENGAJAR
			</a>
			<span class="badge">35</span>
		</li>
		<li>
			<a href="http://localhost/design-adm/index.php#mapel">
				<i class="icon ion-ios-bookmarks-outline"></i>
				MATA PELAJARAN
			</a>
		</li>
		<li>
			<a href="http://localhost/design-adm/index.php#jurusan">
				<i class="icon ion-erlenmeyer-flask"></i>
				JURUSAN
			</a>
			<span class="badge">25</span>
		</li>
	</ul>
</div>